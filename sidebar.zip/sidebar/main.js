document.getElementById('close').addEventListener('click', closeMenu)
document.getElementById('open').addEventListener('click', openMenu)


function closeMenu (e){
    console.log('this is insane')
    if (e.target.id == 'closing'){
        console.log('this is crazy')
        const sidebarClose = document.getElementById('sidebar')
        sidebarClose.style.marginLeft = '-250px'

        document.getElementById('open').style.visibility = 'visible'
    }
}

function openMenu (e) {
    console.log('insane')
    if(e.target.id == 'opening'){
        const sidebarOpen = document.getElementById('sidebar')
        sidebarOpen.style.marginLeft = '0px'

        document.getElementById('openbtn').style.visibility = 'hidden'
    }
}